// Initialize necessary tools
let express = require("express");


let app = express();

let path = require("path");

let bodyParser = require('body-parser');

const port = 5000;

let security = false;

// Set up EJS view
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({extended: true}));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Connect to database
const knex = require("knex") ({
    client : "pg",
    connection : {
        host : "database-1.c7oymg6a6oyf.us-east-1.rds.amazonaws.com",
        user : "postgres",
        password : "bryceellaalainarex123",
        database : "TSP_Information",
        port : 5432,
        ssl: { rejectUnauthorized: false }
    }
});

app.get('/', (req, res) => {
    res.render('index')
});

app.get('/eventForm', (req, res) => {
    res.render('eventForm')
});

app.post('/eventForm', async (req, res) => {
    try {
      // Insert the contact information and get the inserted contact_id
      const [{ contact_id }] = await knex('contacts')
        .insert({
          event_contact_first_name: req.body.event_contact_first_name,
          event_contact_last_name: req.body.event_contact_last_name,
          event_contact_phone: req.body.event_contact_phone,
          event_contact_email: req.body.event_contact_email,
          event_contact_organization: req.body.event_contact_organization
        })
        .returning('contact_id');
  
      // Insert the event information, using the contact_id as a foreign key
      await knex('events')
        .insert({
          event_name: req.body.event_name,
          event_date: req.body.event_date,
          event_address: req.body.event_address,
          event_city: req.body.event_city,
          event_state: req.body.event_state,
          event_zipcode: req.body.event_zipcode,
          event_start_time: req.body.event_start_time,
          event_end_time: req.body.event_end_time,
          jen_story: req.body.jen_story,
          event_status: 'PENDING',
          num_participants: req.body.num_participants,
          contact_id: parseInt(contact_id)
        });
  
      // Redirect or render the success page
      res.render('help');
    } catch (err) {
      console.error('Error inserting event:', err);
      res.status(500).json({ error: 'An error occurred while inserting the event.' });
    }
  });

app.get('/jensStory', (req, res) => {
    res.render('jensStory')
});

app.get('/volunteerForm', (req, res) => {
    res.render('volunteerForm')
});

app.get('/help', (req, res) => {
    res.render('help')
});

app.get('/donate', (req, res) => {
    res.render('donate')
});

app.get('/contactUs', (req, res) => {
    res.render('contactUs')
})

app.get('/login', (req, res) => {
    res.render('login')
});

app.get('/success', (req, res) => {
    res.render('success')
});

app.get('/admin', (req, res) => {
    knex('volunteers').where('vol_type', 'A').then(admin => {
        res.render('admin', {admin})
    })
});

app.get('/editAdmin/:id', (req, res) => {
    knex('volunteers').where('volunteer_id', req.params.id).first()
    .then(admin => {
        res.render('editAdmin', {admin})
    })
});

app.post('/editAdmin/:id', (req, res) => {
    knex('volunteers').where('volunteer_id', req.params.id)
    .update({
        vol_first_name: req.body.vol_first_name,
        vol_last_name: req.body.vol_last_name,
        vol_email: req.body.vol_email,
        vol_phone: req.body.vol_phone,
        vol_address: req.body.vol_address,
        vol_city: req.body.vol_city,
        vol_state: req.body.vol_state,
        vol_zipcode: req.body.vol_zipcode,
        username: req.body.username
    })
    .then(admin => {
        res.redirect('/admin')
    })
});

app.get('/addAdmin', (req, res) => {
    res.render('addAdmin')
});

app.post('/addAdmin', (req, res) => {
    knex('volunteers')
    .insert({
        vol_first_name: req.body.vol_first_name,
        vol_last_name: req.body.vol_last_name,
        vol_email: req.body.vol_email,
        vol_phone: req.body.vol_phone,
        vol_address: req.body.vol_address,
        vol_city: req.body.vol_city,
        vol_state: req.body.vol_state,
        vol_zipcode: req.body.vol_zipcode,
        vol_sewing_level: req.body.vol_sewing_level,
        vol_available_monthly_hours: req.body.vol_available_monthly_hours,
        username: req.body.username,
        password: req.body.password,
        vol_type: 'A'
    })
    .then(admin => {
        res.redirect('/admin')
    })
});

app.post('/deleteAdmin/:id', (req, res) => {
    knex('volunteers').where('volunteer_id', req.params.id).del()
    .then(admin => {
        res.redirect('/admin')
    })
});

app.get('/eventRequests', (req, res) => {
    res.render('eventRequests')
});

app.get('/volunteer', (req, res) => {
    knex('volunteers').join('finding_sources', 'volunteers.vol_finding_source', '=','finding_sources.source_id')
    .select(
        'volunteers.volunteer_id',
        'volunteers.vol_first_name',
        'volunteers.vol_last_name',
        'volunteers.vol_email',
        'volunteers.vol_phone',
        'volunteers.vol_address',
        'volunteers.vol_city',
        'volunteers.vol_state',
        'volunteers.vol_zipcode',
        'volunteers.vol_sewing_level',
        'volunteers.vol_available_monthly_hours',
        'finding_sources.source_type as vol_finding_source'
    ).where('vol_type', 'B')
    .then(volunteer => {
        res.render('volunteer', {volunteer})
    })
       
    });

app.post('/login', async (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    console.log('Username:', username);
    console.log('Password:', password);
  
    try {
      // Query the database for the user
      let user = await knex('volunteers').select('username', 'password', 'vol_type').where('username', username).first();
  
      console.log('Retrieved user:', user);
      console.log('Type: ', user.vol_type)
  
      if (!user) {
        return res.status(401).json({ error: 'Invalid username' });
      }
  
      const isPasswordValid = user.password === password;
  
      if (!isPasswordValid) {
        return res.status(401).json({ error: 'Invalid password' });
      }

      if (user.vol_type == 'B') {
        return res.status(401).json({ error: 'Unauthorized login' })
      }
  
      // Render the specific page if credentials are valid
      return res.status(200).json({ message: 'Login successful!' });
    } catch (error) {
      console.error('Error during login:', error);
      res.status(500).json({ error: 'An error occurred. Please try again later.' });
    }
  });

app.get('/editVolunteer/:id', (req, res) => {
    knex('volunteers').where('volunteer_id', req.params.id).first()
    .then(volunteer => {
        knex('finding_sources').then(finding_source => {
            res.render('editVolunteer', {volunteer, finding_source})
        })
    })
});

app.post('/editVolunteer/:id', (req, res) => {
    knex('volunteers').where('volunteer_id', req.params.id)
    .update({
        vol_first_name: req.body.vol_first_name,
        vol_last_name: req.body.vol_last_name,
        vol_email: req.body.vol_email,
        vol_phone: req.body.vol_phone,
        vol_address: req.body.vol_address,
        vol_city: req.body.vol_city,
        vol_state: req.body.vol_state,
        vol_zipcode: req.body.vol_zipcode,
        vol_sewing_level: req.body.vol_sewing_level,
        vol_available_monthly_hours: req.body.vol_available_monthly_hours,
        vol_finding_source: req.body.vol_finding_source
    })
    .then(volunteer => {
        res.redirect('/volunteer')
    })
});

app.post('/deleteVolunteer/:id', (req, res) => {
    knex('volunteers').where('volunteer_id', req.params.id).del()
    .then(volunteer => {
        res.redirect('/volunteer')
    })
});

app.get('/addVolunteer', (req, res) => {
    knex('finding_sources').then(finding_source => {
        res.render('addVolunteer', {finding_source})
    })
})

app.post('/addVolunteer', (req, res) => {
    knex('volunteers').insert({
        vol_first_name: req.body.vol_first_name,
        vol_last_name: req.body.vol_last_name,
        vol_email: req.body.vol_email,
        vol_phone: req.body.vol_phone,
        vol_address: req.body.vol_address,
        vol_city: req.body.vol_city,
        vol_state: req.body.vol_state,
        vol_zipcode: req.body.vol_zipcode,
        vol_sewing_level: req.body.vol_sewing_level,
        vol_available_monthly_hours: req.body.vol_available_monthly_hours,
        vol_finding_source: req.body.vol_finding_source,
        vol_type: 'B'
    })
    .then(volunteer => {
        res.redirect('/volunteer')
    })
});

app.get('/sponsors', (req, res) => {
    res.render('sponsors')
});

// Add after your other requires
const nodemailer = require('nodemailer');

// Create email transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'thecoolbears1.8@gmail.com',
        pass: 'rwqicsfinurxhfzd'
    }
});

// Add this with your other routes
app.post('/api/contact', async (req, res) => {
    const { firstName, lastName, email, subject, message } = req.body;

    // Validate required fields
    if (!firstName || !lastName || !email || !subject || !message) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    // Create email content
    const mailOptions = {
        from: 'thecoolbears1.8@gmail.com',
        to: 'thecoolbears1.8@gmail.com',
        subject: `Contact Form: ${subject}`,
        html: `
            <h2>New Contact Form Submission</h2>
            <p><strong>Name:</strong> ${firstName} ${lastName}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Subject:</strong> ${subject}</p>
            <p><strong>Message:</strong></p>
            <p>${message}</p>
        `
    };

    try {
        await transporter.sendMail(mailOptions);
        res.status(200).json({ message: 'Email sent successfully' });
    } catch (error) {
        console.error('Error sending email:', error);
        res.status(500).json({ error: 'Failed to send email' });
    }
});

app.listen(port, () => console.log('Listening...'));